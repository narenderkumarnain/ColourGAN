__version__ = '1.0.2'

from colourgan.model import ColourGAN
from colourgan.data import Cifar10Dataset
from colourgan.config import get_cfg

